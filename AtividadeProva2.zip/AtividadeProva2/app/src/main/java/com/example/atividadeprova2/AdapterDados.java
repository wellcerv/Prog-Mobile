package com.example.atividadeprova2;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.ArrayList;

public class AdapterDados extends RecyclerView.Adapter<AdapterDados.ViewHolder> {

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView txtNome, txtTelefone;

        public ViewHolder(@NonNull final View itemView){

            super(itemView);

            txtNome = itemView.findViewById(R.id.txtNome);
            txtTelefone = itemView.findViewById(R.id.txtTelefone);

            itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){

                    if(listaDados.size() > 0){

                        Item item = listaDados.get(getLayoutPosition());
                        Intent it = new Intent(itemView.getContext(), MainActivity.class);

                        it.putExtra("DADOS", (Serializable) item);

                        itemView.getContext().startActivity(it);
                        ((MainActivity)itemView.getContext()).finish();

                    }
                }
            });
        }

    }

    ArrayList<Item> listaDados;

    public  AdapterDados(ArrayList<Item> listaDados){
        this.listaDados = listaDados;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista, null, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position){
        holder.txtNome.setText(listaDados.get(position).getNome());
        holder.txtTelefone.setText(listaDados.get(position).getTelefone());

    }

    @Override
    public int getItemCount(){
        return listaDados.size();
    }

}
