package com.example.atividadeprova2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private SQLiteDatabase conexao;
    private DadosOpenHelper dadosOpenHelper;
    private ItemRepositorio itemRepositorio;
    private Item item;
    private Integer codigo;

    ArrayList<Item> listaDados;
    RecyclerView recycle;

    FloatingActionButton fabIncluir, fabEditar, fabExcluir;
    EditText edtNome, edtTelefone;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fabIncluir = findViewById(R.id.fabIncluir);
        fabEditar = findViewById(R.id.fabEditar);
        fabExcluir = findViewById(R.id.fabExcluir);

        edtNome = findViewById(R.id.edtNome);
        edtTelefone = findViewById(R.id.edtTelefone);

        recycle = findViewById(R.id.RecyclerLista);
        recycle.setLayoutManager(new LinearLayoutManager(this, LinearLayout.VERTICAL, false));


        // Botão Incluir ativo e Botões Editar e Excluir desativo
        fabIncluir.show();
        fabEditar.hide();
        fabExcluir.hide();

        criarConexao();

        // Monta a lista buscando do banco no recycle View na pagina.
        listaDados = itemRepositorio.buscarTodos();
        if(listaDados != null){
            AdapterDados adapter = new AdapterDados(listaDados);
            recycle.setAdapter(adapter);
        }

        // Sessão que faz a SELEÇÃO dos itens da agenda e traz para os campos nome e telefone
        Bundle bundle = getIntent().getExtras();

        item = new Item();

        if(bundle !=null && bundle.containsKey("DADOS")){

            // Desativar o botão Incluir e ativar os botões Editar e Excluir
            fabIncluir.hide();
            fabEditar.show();
            fabExcluir.show();

            // Preenchimento dos campos Nome e Telefone ao selecionar um contato
            item = (Item)bundle.getSerializable("DADOS");
            codigo = item.getCodigo();
            edtNome.setText(item.getNome());
            edtTelefone.setText(item.getTelefone());
        }


        // Função que faz o botão Salvar ou Incluir funcionar - Grava o item atual no banco
        fabIncluir.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                item = new Item();
                item.setNome(edtNome.getText().toString());
                item.setTelefone(edtTelefone.getText().toString());

                if((edtNome.getText().toString().isEmpty()) || (edtTelefone.getText().toString().isEmpty())){

                    Toast.makeText(getApplicationContext(), "Preencher Nome e Telefone", Toast.LENGTH_SHORT).show();

                }else {

                    itemRepositorio.inserir(item);

                    Toast.makeText(getApplicationContext(), "Inclusão Efetuada com Sucesso", Toast.LENGTH_SHORT).show();

                }

                Intent it = new Intent(MainActivity.this, MainActivity.class);

                listaDados = itemRepositorio.buscarTodos();

                if(listaDados != null){
                    AdapterDados adapter = new AdapterDados(listaDados);
                    recycle.setAdapter(adapter);
                }

                startActivity(it);
                finish();
            }
        });

        //Função do botão EDITAR.
        fabEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Item item = new Item();

                item.setCodigo(codigo);
                item.setNome(edtNome.getText().toString());
                item.setTelefone(edtTelefone.getText().toString());

                if((edtNome.getText().toString().isEmpty()) || (edtTelefone.getText().toString().isEmpty())){

                    Toast.makeText(getApplicationContext(), "Preencher Nome e Telefone", Toast.LENGTH_SHORT).show();

                }else{

                    itemRepositorio.alterar(item);

                    Toast.makeText(getApplicationContext(), "Alteração efetuada com sucesso!", Toast.LENGTH_SHORT).show();
                }

                Intent it = new Intent(MainActivity.this, MainActivity.class);

                listaDados = itemRepositorio.buscarTodos();

                if(listaDados != null){
                    AdapterDados adapter = new AdapterDados(listaDados);
                    recycle.setAdapter(adapter);
                }

                startActivity(it);
                finish();
            }
        });

        //Função do botão EXCLUIR.
        fabExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                itemRepositorio.excluir(codigo);

                Toast.makeText(getApplicationContext(), "Exclusão efetuada com sucesso!", Toast.LENGTH_SHORT).show();

                Intent it = new Intent(MainActivity.this, MainActivity.class);

                listaDados = itemRepositorio.buscarTodos();

                if(listaDados != null){
                    AdapterDados adapter = new AdapterDados(listaDados);
                    recycle.setAdapter(adapter);
                }

                startActivity(it);
                finish();
            }
        });
    }

    private void criarConexao(){

        try {
            dadosOpenHelper = new DadosOpenHelper(this);
            conexao = dadosOpenHelper.getWritableDatabase();
            itemRepositorio = new ItemRepositorio(conexao);
        }catch (SQLException e){
            Toast.makeText(getApplicationContext(), "Problema ao conectar!", Toast.LENGTH_SHORT).show();
        }
    }


    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_item, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.limpar:
                this.edtNome.setText("");
                this.edtTelefone.setText("");
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
